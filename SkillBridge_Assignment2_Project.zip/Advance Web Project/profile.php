<?php
$pageTitle = 'My Profile';
require_once 'includes/functions.php';
require_role('freelancer');

$uid = $_SESSION['user_id'];
$categories = $conn->query("SELECT id, name FROM categories ORDER BY id")->fetch_all(MYSQLI_ASSOC);

$stmt = $conn->prepare("SELECT category_id, headline, bio, skills FROM freelancer_profiles WHERE user_id = ?");
$stmt->bind_param('i', $uid);
$stmt->execute();
$existing = $stmt->get_result()->fetch_assoc();
$old = $existing ?: ['category_id' => '', 'headline' => '', 'bio' => '', 'skills' => ''];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($old as $k => $_) $old[$k] = trim($_POST[$k] ?? '');

    if (!csrf_valid()) $errors['form'] = 'Invalid form token. Please refresh and try again.';
    if (!in_array((int)$old['category_id'], array_column($categories, 'id'))) $errors['category_id'] = 'Please choose your main skill category.';
    if (mb_strlen($old['headline']) < 3 || mb_strlen($old['headline']) > 100) $errors['headline'] = 'Headline must be 3 to 100 characters.';
    if (mb_strlen($old['bio']) < 10 || mb_strlen($old['bio']) > 300) $errors['bio'] = 'Bio must be 10 to 300 characters.';
    if ($old['skills'] === '' || mb_strlen($old['skills']) > 200) $errors['skills'] = 'Enter 1-200 characters of skills, separated by commas.';

    if (!$errors) {
        $cat = (int)$old['category_id'];
        if ($existing) {
            $q = $conn->prepare("UPDATE freelancer_profiles SET category_id=?, headline=?, bio=?, skills=? WHERE user_id=?");
            $q->bind_param('isssi', $cat, $old['headline'], $old['bio'], $old['skills'], $uid);
        } else {
            $q = $conn->prepare("INSERT INTO freelancer_profiles (category_id, headline, bio, skills, user_id) VALUES (?,?,?,?,?)");
            $q->bind_param('isssi', $cat, $old['headline'], $old['bio'], $old['skills'], $uid);
        }
        $q->execute();
        set_flash('success', 'Profile saved. You are now listed on the Freelancers page.');
        redirect('dashboard.php');
    }
}
require_once 'includes/header.php';
function pe(array $e, string $k): string { return isset($e[$k]) ? '<div class="invalid-feedback d-block">' . e($e[$k]) . '</div>' : ''; }
function pc(array $e, string $k): string { return isset($e[$k]) ? ' is-invalid' : ''; }
?>
<section class="dark-section">
    <div class="container mt-5">
        <div class="row justify-content-center"><div class="col-lg-7">
            <div class="form-card">
                <h4 class="mb-4"><?= $existing ? 'Edit' : 'Create' ?> your freelancer profile</h4>
                <?php if (isset($errors['form'])): ?><div class="alert alert-danger"><?= e($errors['form']) ?></div><?php endif; ?>
                <form method="post" action="profile.php" novalidate>
                    <?= csrf_field() ?>
                    <div class="mb-3"><label for="category_id">Main skill category</label>
                        <select id="category_id" name="category_id" class="form-select<?= pc($errors,'category_id') ?>">
                            <option value="">Choose...</option>
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= (int)$c['id'] ?>" <?= (string)$c['id'] === (string)$old['category_id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                            <?php endforeach; ?>
                        </select><?= pe($errors,'category_id') ?></div>
                    <div class="mb-3"><label for="headline">Headline</label>
                        <input id="headline" name="headline" class="form-control<?= pc($errors,'headline') ?>" placeholder="e.g. Web Developer" value="<?= e($old['headline']) ?>"><?= pe($errors,'headline') ?></div>
                    <div class="mb-3"><label for="bio">Short bio</label>
                        <textarea id="bio" name="bio" rows="3" class="form-control<?= pc($errors,'bio') ?>"><?= e($old['bio']) ?></textarea><?= pe($errors,'bio') ?></div>
                    <div class="mb-4"><label for="skills">Skills (comma separated)</label>
                        <input id="skills" name="skills" class="form-control<?= pc($errors,'skills') ?>" placeholder="React, Node.js, CSS" value="<?= e($old['skills']) ?>"><?= pe($errors,'skills') ?></div>
                    <button class="btn btn-primary px-5">Save Profile</button>
                    <a href="dashboard.php" class="btn btn-outline-dark ms-2">Cancel</a>
                </form>
            </div>
        </div></div>
    </div>
</section>
<?php require 'includes/footer.php'; ?>
