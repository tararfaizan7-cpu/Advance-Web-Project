<?php
require_once 'includes/functions.php';
require_role('client');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_valid()) { set_flash('danger', 'Invalid request.'); redirect('dashboard.php'); }

$appId  = (int)($_POST['application_id'] ?? 0);
$status = $_POST['action'] ?? '';
if (!in_array($status, ['accepted', 'rejected'], true)) { set_flash('danger', 'Unknown action.'); redirect('dashboard.php'); }

// Only the client who owns the job may change the application
$q = $conn->prepare(
    "UPDATE applications a JOIN jobs j ON j.id = a.job_id
        SET a.status = ? WHERE a.id = ? AND j.client_id = ?");
$q->bind_param('sii', $status, $appId, $_SESSION['user_id']);
$q->execute();
set_flash($q->affected_rows ? 'success' : 'danger', $q->affected_rows ? 'Application ' . $status . '.' : 'Application not found.');
redirect('dashboard.php');
