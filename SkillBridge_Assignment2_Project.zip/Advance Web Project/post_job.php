<?php
$pageTitle = 'Post a Job';
require_once 'includes/functions.php';
require_role('client');                      // role-based access: clients only

$categories = $conn->query("SELECT id, name FROM categories ORDER BY id")->fetch_all(MYSQLI_ASSOC);
$errors = [];
$old = ['title' => '', 'category_id' => '', 'description' => '', 'skills' => '', 'budget' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($old as $k => $_) $old[$k] = trim($_POST[$k] ?? '');

    if (!csrf_valid()) $errors['form'] = 'Invalid form token. Please refresh and try again.';
    if (mb_strlen($old['title']) < 5 || mb_strlen($old['title']) > 120) $errors['title'] = 'Title must be 5 to 120 characters.';
    if (!in_array((int)$old['category_id'], array_column($categories, 'id'))) $errors['category_id'] = 'Please choose a category.';
    if (mb_strlen($old['description']) < 20) $errors['description'] = 'Description must be at least 20 characters.';
    if ($old['skills'] === '' || mb_strlen($old['skills']) > 200) $errors['skills'] = 'Enter 1-200 characters of skills, separated by commas.';
    if (!ctype_digit($old['budget']) || (int)$old['budget'] < 500 || (int)$old['budget'] > 10000000)
        $errors['budget'] = 'Budget must be a whole number between 500 and 10,000,000.';

    if (!$errors) {
        $cat = (int)$old['category_id']; $budget = (int)$old['budget'];
        $stmt = $conn->prepare("INSERT INTO jobs (client_id, category_id, title, description, skills, budget) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param('iisssi', $_SESSION['user_id'], $cat, $old['title'], $old['description'], $old['skills'], $budget);
        $stmt->execute();
        set_flash('success', 'Your job has been posted.');
        redirect('dashboard.php');
    }
}
require_once 'includes/header.php';
function er(array $e, string $k): string { return isset($e[$k]) ? '<div class="invalid-feedback d-block">' . e($e[$k]) . '</div>' : ''; }
function ic(array $e, string $k): string { return isset($e[$k]) ? ' is-invalid' : ''; }
?>
<section class="dark-section">
    <div class="container mt-5">
        <div class="row justify-content-center"><div class="col-lg-8">
            <div class="form-card">
                <h4 class="mb-4">Post a new job</h4>
                <?php if (isset($errors['form'])): ?><div class="alert alert-danger"><?= e($errors['form']) ?></div><?php endif; ?>
                <form method="post" action="post_job.php" novalidate>
                    <?= csrf_field() ?>
                    <div class="row g-3">
                        <div class="col-12"><label for="title">Job title</label>
                            <input id="title" name="title" class="form-control<?= ic($errors,'title') ?>" value="<?= e($old['title']) ?>" required><?= er($errors,'title') ?></div>
                        <div class="col-md-6"><label for="category_id">Category</label>
                            <select id="category_id" name="category_id" class="form-select<?= ic($errors,'category_id') ?>" required>
                                <option value="">Choose...</option>
                                <?php foreach ($categories as $c): ?>
                                    <option value="<?= (int)$c['id'] ?>" <?= (string)$c['id'] === $old['category_id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                                <?php endforeach; ?>
                            </select><?= er($errors,'category_id') ?></div>
                        <div class="col-md-6"><label for="budget">Budget (Rs.)</label>
                            <input id="budget" name="budget" type="number" class="form-control<?= ic($errors,'budget') ?>" value="<?= e($old['budget']) ?>" required><?= er($errors,'budget') ?></div>
                        <div class="col-12"><label for="skills">Skills (comma separated)</label>
                            <input id="skills" name="skills" class="form-control<?= ic($errors,'skills') ?>" placeholder="HTML, CSS, JavaScript" value="<?= e($old['skills']) ?>" required><?= er($errors,'skills') ?></div>
                        <div class="col-12"><label for="description">Description</label>
                            <textarea id="description" name="description" rows="5" class="form-control<?= ic($errors,'description') ?>" required><?= e($old['description']) ?></textarea><?= er($errors,'description') ?></div>
                        <div class="col-12"><button class="btn btn-primary btn-lg px-5">Post Job</button>
                            <a href="dashboard.php" class="btn btn-outline-dark btn-lg ms-2">Cancel</a></div>
                    </div>
                </form>
            </div>
        </div></div>
    </div>
</section>
<?php require 'includes/footer.php'; ?>
