<?php
require_once '../includes/functions.php';
require_role('admin');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_valid()) { set_flash('danger', 'Invalid request.'); redirect('index.php'); }

$id   = (int)($_POST['id'] ?? 0);
$type = $_POST['type'] ?? '';

if ($type === 'user') {
    // admins can never be deleted from the panel
    $q = $conn->prepare("DELETE FROM users WHERE id = ? AND role <> 'admin'");
} elseif ($type === 'job') {
    $q = $conn->prepare("DELETE FROM jobs WHERE id = ?");
} else {
    set_flash('danger', 'Unknown action.'); redirect('index.php');
}
$q->bind_param('i', $id);
$q->execute();
set_flash($q->affected_rows ? 'success' : 'danger', $q->affected_rows ? ucfirst($type) . ' deleted.' : 'Nothing was deleted.');
redirect('index.php');
