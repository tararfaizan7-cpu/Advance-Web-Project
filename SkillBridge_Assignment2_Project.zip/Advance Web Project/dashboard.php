<?php
$pageTitle = 'Dashboard';
require_once 'includes/functions.php';
require_login();
if (has_role('admin')) redirect('admin/index.php');

$uid  = $_SESSION['user_id'];
$role = current_role();

if ($role === 'freelancer') {
    $q = $conn->prepare(
        "SELECT a.status, a.applied_at, j.id AS job_id, j.title, j.budget, u.full_name AS client
           FROM applications a JOIN jobs j ON j.id = a.job_id JOIN users u ON u.id = j.client_id
          WHERE a.freelancer_id = ? ORDER BY a.applied_at DESC");
    $q->bind_param('i', $uid); $q->execute();
    $applications = $q->get_result()->fetch_all(MYSQLI_ASSOC);

    $q = $conn->prepare(
        "SELECT j.id, j.title, j.budget, j.status FROM saved_jobs s JOIN jobs j ON j.id = s.job_id
          WHERE s.user_id = ? ORDER BY s.saved_at DESC");
    $q->bind_param('i', $uid); $q->execute();
    $savedJobs = $q->get_result()->fetch_all(MYSQLI_ASSOC);

    $q = $conn->prepare("SELECT 1 FROM freelancer_profiles WHERE user_id = ?");
    $q->bind_param('i', $uid); $q->execute();
    $hasProfile = $q->get_result()->num_rows > 0;
} else { // client
    $q = $conn->prepare(
        "SELECT j.*, c.name AS category, (SELECT COUNT(*) FROM applications a WHERE a.job_id = j.id) AS applicants
           FROM jobs j JOIN categories c ON c.id = j.category_id
          WHERE j.client_id = ? ORDER BY j.created_at DESC, j.id DESC");
    $q->bind_param('i', $uid); $q->execute();
    $myJobs = $q->get_result()->fetch_all(MYSQLI_ASSOC);

    $q = $conn->prepare(
        "SELECT a.id, a.job_id, a.cover_letter, a.status, a.applied_at, u.full_name, u.email, p.headline
           FROM applications a
           JOIN jobs j ON j.id = a.job_id
           JOIN users u ON u.id = a.freelancer_id
      LEFT JOIN freelancer_profiles p ON p.user_id = u.id
          WHERE j.client_id = ? ORDER BY a.applied_at DESC");
    $q->bind_param('i', $uid); $q->execute();
    $byJob = [];
    foreach ($q->get_result()->fetch_all(MYSQLI_ASSOC) as $row) $byJob[$row['job_id']][] = $row;
}

require_once 'includes/header.php';
function status_badge(string $s): string
{
    $map = ['pending' => 'warning text-dark', 'accepted' => 'success', 'rejected' => 'danger', 'open' => 'success', 'closed' => 'secondary'];
    return '<span class="badge text-bg-' . ($map[$s] ?? 'secondary') . '">' . e(ucfirst($s)) . '</span>';
}
?>
<section class="dark-section">
    <div class="container mt-5">
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
            <div>
                <h2 class="mb-1">Welcome, <?= e($_SESSION['full_name']) ?></h2>
                <span class="badge text-bg-primary"><?= e(ucfirst($role)) ?> account</span>
            </div>
            <?php if ($role === 'client'): ?>
                <a href="post_job.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Post a Job</a>
            <?php else: ?>
                <a href="profile.php" class="btn btn-primary"><i class="bi bi-person-lines-fill"></i> <?= $hasProfile ? 'Edit' : 'Create' ?> Profile</a>
            <?php endif; ?>
        </div>

<?php if ($role === 'freelancer'): ?>
        <?php if (!$hasProfile): ?>
            <div class="alert alert-info">Create your freelancer profile so clients can find you on the Freelancers page.</div>
        <?php endif; ?>
        <div class="row g-4">
            <div class="col-lg-8"><div class="form-card">
                <h4 class="mb-3">My Applications (<?= count($applications) ?>)</h4>
                <?php if (!$applications): ?><p>You haven't applied for any job yet. <a href="find_job.php">Browse jobs</a>.</p><?php else: ?>
                <div class="table-responsive"><table class="table align-middle">
                    <thead><tr><th>Job</th><th>Client</th><th>Budget</th><th>Applied</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php foreach ($applications as $a): ?>
                        <tr><td><a href="apply_job.php?id=<?= (int)$a['job_id'] ?>"><?= e($a['title']) ?></a></td>
                            <td><?= e($a['client']) ?></td><td>Rs. <?= number_format($a['budget']) ?></td>
                            <td><?= e(date('d M Y', strtotime($a['applied_at']))) ?></td><td><?= status_badge($a['status']) ?></td></tr>
                    <?php endforeach; ?>
                    </tbody></table></div>
                <?php endif; ?>
            </div></div>
            <div class="col-lg-4"><div class="form-card">
                <h4 class="mb-3">Saved Jobs (<?= count($savedJobs) ?>)</h4>
                <?php if (!$savedJobs): ?><p>Tap the heart on a job to save it.</p><?php endif; ?>
                <?php foreach ($savedJobs as $s): ?>
                    <div class="d-flex justify-content-between border-bottom py-2">
                        <a href="apply_job.php?id=<?= (int)$s['id'] ?>"><?= e($s['title']) ?></a>
                        <small>Rs. <?= number_format($s['budget']) ?></small>
                    </div>
                <?php endforeach; ?>
            </div></div>
        </div>

<?php else: ?>
        <h4 class="mb-3">My Jobs (<?= count($myJobs) ?>)</h4>
        <?php if (!$myJobs): ?><div class="form-card"><p class="mb-0">You haven't posted any job yet.</p></div><?php endif; ?>
        <?php foreach ($myJobs as $j): $apps = $byJob[$j['id']] ?? []; ?>
            <div class="form-card mb-4">
                <div class="d-flex flex-wrap justify-content-between gap-2">
                    <div>
                        <span class="job-category"><?= e($j['category']) ?></span>
                        <h4 class="mb-1"><?= e($j['title']) ?></h4>
                        <small>Rs. <?= number_format($j['budget']) ?> · <?= (int)$j['applicants'] ?> applicant(s) · <?= status_badge($j['status']) ?></small>
                    </div>
                    <form method="post" action="job_action.php" class="d-flex gap-2 align-items-start"
                          onsubmit="return this.action.value!=='delete' || confirm('Delete this job and its applications?')">
                        <?= csrf_field() ?><input type="hidden" name="job_id" value="<?= (int)$j['id'] ?>">
                        <button name="action" value="<?= $j['status'] === 'open' ? 'close' : 'open' ?>" class="btn btn-sm btn-outline-dark">
                            <?= $j['status'] === 'open' ? 'Close' : 'Reopen' ?></button>
                        <button name="action" value="delete" class="btn btn-sm btn-outline-danger">Delete</button>
                    </form>
                </div>
                <?php if ($apps): ?>
                    <hr><h6 class="mb-3">Applicants</h6>
                    <?php foreach ($apps as $a): ?>
                        <div class="border rounded-3 p-3 mb-2">
                            <div class="d-flex flex-wrap justify-content-between gap-2">
                                <div><strong><?= e($a['full_name']) ?></strong>
                                    <?= $a['headline'] ? '<span class="text-muted"> · ' . e($a['headline']) . '</span>' : '' ?>
                                    <br><small><?= e($a['email']) ?></small></div>
                                <div><?= status_badge($a['status']) ?></div>
                            </div>
                            <p class="mt-2 mb-2" style="white-space:pre-line"><?= e($a['cover_letter']) ?></p>
                            <?php if ($a['status'] === 'pending'): ?>
                            <form method="post" action="application_action.php" class="d-flex gap-2">
                                <?= csrf_field() ?><input type="hidden" name="application_id" value="<?= (int)$a['id'] ?>">
                                <button name="action" value="accepted" class="btn btn-sm btn-success">Accept</button>
                                <button name="action" value="rejected" class="btn btn-sm btn-outline-danger">Reject</button>
                            </form>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
<?php endif; ?>
    </div>
</section>
<?php require 'includes/footer.php'; ?>
