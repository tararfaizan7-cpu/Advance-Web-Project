<?php
require_once 'includes/functions.php';
require_role('client');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_valid()) { set_flash('danger', 'Invalid request.'); redirect('dashboard.php'); }

$jobId  = (int)($_POST['job_id'] ?? 0);
$action = $_POST['action'] ?? '';
$uid    = $_SESSION['user_id'];

if ($action === 'delete') {
    $q = $conn->prepare("DELETE FROM jobs WHERE id = ? AND client_id = ?");        // owner check inside the query
    $q->bind_param('ii', $jobId, $uid);
    $msg = 'Job deleted.';
} elseif ($action === 'close' || $action === 'open') {
    $status = $action === 'close' ? 'closed' : 'open';
    $q = $conn->prepare("UPDATE jobs SET status = ? WHERE id = ? AND client_id = ?");
    $q->bind_param('sii', $status, $jobId, $uid);
    $msg = 'Job ' . ($status === 'open' ? 'reopened.' : 'closed.');
} else {
    set_flash('danger', 'Unknown action.'); redirect('dashboard.php');
}
$q->execute();
set_flash($q->affected_rows ? 'success' : 'danger', $q->affected_rows ? $msg : 'Job not found or not yours.');
redirect('dashboard.php');
