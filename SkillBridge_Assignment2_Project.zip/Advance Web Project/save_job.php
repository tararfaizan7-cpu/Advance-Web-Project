<?php
require_once 'includes/functions.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_valid()) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Bad request']); exit;
}
if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'login']); exit;
}

$jobId = (int)($_POST['job_id'] ?? 0);
$uid   = $_SESSION['user_id'];

$chk = $conn->prepare("SELECT id FROM jobs WHERE id = ?");
$chk->bind_param('i', $jobId);
$chk->execute();
if (!$chk->get_result()->num_rows) { http_response_code(404); echo json_encode(['ok' => false]); exit; }

$sel = $conn->prepare("SELECT 1 FROM saved_jobs WHERE user_id = ? AND job_id = ?");
$sel->bind_param('ii', $uid, $jobId);
$sel->execute();

if ($sel->get_result()->num_rows) {
    $q = $conn->prepare("DELETE FROM saved_jobs WHERE user_id = ? AND job_id = ?");
    $saved = false;
} else {
    $q = $conn->prepare("INSERT INTO saved_jobs (user_id, job_id) VALUES (?, ?)");
    $saved = true;
}
$q->bind_param('ii', $uid, $jobId);
$q->execute();
echo json_encode(['ok' => true, 'saved' => $saved]);
