<?php
/**
 * Shared helpers: session, flash messages, CSRF, auth guards.
 * Included at the top of every page.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

require_once __DIR__ . '/../config/database.php';

/* Fallback in case the mbstring extension is not enabled on the server */
if (!function_exists('mb_strlen')) {
    function mb_strlen(string $s): int { return (int)preg_match_all('/./us', $s); }
}

/** Escape output (prevents XSS). */
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/* ---------- Flash messages (stored in session, shown once) ---------- */
function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array
{
    if (!isset($_SESSION['flash'])) {
        return null;
    }
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

/* ---------- CSRF protection for every POST form ---------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

function csrf_valid(): bool
{
    return isset($_POST['csrf'], $_SESSION['csrf'])
        && hash_equals($_SESSION['csrf'], $_POST['csrf']);
}

/* ---------- Authentication helpers ---------- */
function is_logged_in(): bool
{
    return isset($_SESSION['user_id']);
}

function current_role(): ?string
{
    return $_SESSION['role'] ?? null;
}

function has_role(string ...$roles): bool
{
    return is_logged_in() && in_array(current_role(), $roles, true);
}

/** '' for normal pages, '../' when the current script lives inside /admin. */
function root_prefix(): string
{
    return basename(dirname($_SERVER['SCRIPT_NAME'])) === 'admin' ? '../' : '';
}

/** Current page relative to the project root, e.g. "admin/index.php?x=1". */
function current_page(): string
{
    $page = (root_prefix() ? 'admin/' : '') . basename($_SERVER['SCRIPT_NAME']);
    $qs   = $_SERVER['QUERY_STRING'] ?? '';
    return $qs !== '' ? $page . '?' . $qs : $page;
}

/** Page is only for logged-in users. */
function require_login(): void
{
    if (!is_logged_in()) {
        set_flash('warning', 'Please log in to access that page.');
        redirect(root_prefix() . 'login.php?next=' . urlencode(current_page()));
    }
}

/** Page is only for the given role(s) (role-based access control). */
function require_role(string ...$roles): void
{
    require_login();
    if (!in_array(current_role(), $roles, true)) {
        http_response_code(403);
        set_flash('danger', 'You do not have permission to open that page.');
        redirect(root_prefix() . dashboard_url());
    }
}

function dashboard_url(): string
{
    return current_role() === 'admin' ? 'admin/index.php' : 'dashboard.php';
}

/** Only allow redirects to local pages (blocks open-redirect attacks). */
function safe_next(?string $next): string
{
    if ($next && preg_match('/^[A-Za-z0-9_\-\/]+\.php(\?[A-Za-z0-9_=&\-]*)?$/', $next)) {
        return $next;
    }
    return dashboard_url();
}

/** Split "HTML,CSS,JS" into an array of trimmed skills. */
function skill_list(string $skills): array
{
    return array_filter(array_map('trim', explode(',', $skills)));
}

/** Render rating stars (4.5 -> 4 full + 1 half). */
function stars(float $rating): string
{
    $html = '';
    for ($i = 1; $i <= 5; $i++) {
        if ($rating >= $i)            $html .= '<i class="bi bi-star-fill"></i>';
        elseif ($rating >= $i - 0.5)  $html .= '<i class="bi bi-star-half"></i>';
        else                          $html .= '<i class="bi bi-star"></i>';
    }
    return $html;
}
