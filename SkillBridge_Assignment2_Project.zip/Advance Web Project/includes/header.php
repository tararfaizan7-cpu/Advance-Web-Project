<?php
/**
 * Common <head> + navbar.
 * Set $pageTitle and $activeNav before including this file.
 * $base is the path prefix to the project root ('' or '../' for admin pages).
 */
require_once __DIR__ . '/functions.php';
$pageTitle = $pageTitle ?? 'SkillBridge';
$activeNav = $activeNav ?? '';
$base      = $base ?? '';
$flash     = get_flash();
function nav_active(string $key): string
{
    global $activeNav;
    return $activeNav === $key ? ' active' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf" content="<?= csrf_token() ?>">
    <title><?= e($pageTitle) ?> | SkillBridge</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= $base ?>style.css">
</head>
<body>

<!-- ================= NAVBAR ================= -->
<nav class="navbar navbar-expand-lg navbar-light fixed-top custom-navbar">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= $base ?>index.php">Skill<span> Bridge</span></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarMenu">
            <ul class="navbar-nav ms-auto align-items-lg-center">
                <li class="nav-item"><a class="nav-link<?= nav_active('home') ?>" href="<?= $base ?>index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link<?= nav_active('about') ?>" href="<?= $base ?>about.php">About</a></li>
                <li class="nav-item"><a class="nav-link<?= nav_active('jobs') ?>" href="<?= $base ?>find_job.php">Find Jobs</a></li>
                <li class="nav-item"><a class="nav-link<?= nav_active('freelancers') ?>" href="<?= $base ?>freelancer.php">Freelancers</a></li>
                <li class="nav-item"><a class="nav-link<?= nav_active('contact') ?>" href="<?= $base ?>contact.php">Contact</a></li>

                <?php if (is_logged_in()): ?>
                    <li class="nav-item ms-lg-3">
                        <a class="btn btn-outline-primary px-4" href="<?= $base . dashboard_url() ?>">
                            <i class="bi bi-person-circle"></i> <?= e(explode(' ', $_SESSION['full_name'])[0]) ?>
                        </a>
                    </li>
                    <li class="nav-item ms-lg-2">
                        <a class="btn btn-primary px-4" href="<?= $base ?>logout.php">Logout</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item ms-lg-3"><a class="btn btn-outline-primary px-4" href="<?= $base ?>login.php">Login</a></li>
                    <li class="nav-item ms-lg-2"><a class="btn btn-primary px-4" href="<?= $base ?>register.php">Join Now</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php if ($flash): ?>
    <div class="flash-wrap container">
        <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show shadow-sm" role="alert">
            <?= e($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </div>
<?php endif; ?>
