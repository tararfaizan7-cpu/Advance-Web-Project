<?php $base = $base ?? ''; ?>
<!-- ================= FOOTER ================= -->
<footer>
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4">
                <h3 class="footer-logo">Skill<span>Bridge</span></h3>
                <p>Connecting student talent with real-world opportunities.</p>
                <div class="social-icons">
                    <a href="#"><i class="bi bi-facebook"></i></a>
                    <a href="#"><i class="bi bi-instagram"></i></a>
                    <a href="#"><i class="bi bi-linkedin"></i></a>
                    <a href="#"><i class="bi bi-twitter-x"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-md-4">
                <h5>Quick Links</h5>
                <a href="<?= $base ?>index.php">Home</a>
                <a href="<?= $base ?>about.php">About</a>
                <a href="<?= $base ?>find_job.php">Jobs</a>
                <a href="<?= $base ?>contact.php">Contact</a>
            </div>
            <div class="col-lg-3 col-md-4">
                <h5>For Freelancers</h5>
                <a href="<?= $base ?>find_job.php">Find Jobs</a>
                <a href="<?= $base ?>register.php">Create Profile</a>
                <a href="<?= $base ?>freelancer.php">Browse Talent</a>
            </div>
            <div class="col-lg-3 col-md-4">
                <h5>Newsletter</h5>
                <p>Get the latest freelance opportunities.</p>
                <div class="input-group">
                    <input type="email" class="form-control" placeholder="Email">
                    <button class="btn btn-primary"><i class="bi bi-send"></i></button>
                </div>
            </div>
        </div>
        <hr>
        <p class="text-center copyright">© <?= date('Y') ?> SkillBridge. All Rights Reserved.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= $base ?>script.js"></script>
</body>
</html>
