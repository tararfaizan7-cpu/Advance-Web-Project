<?php
$pageTitle = 'Freelancers';
$activeNav = 'freelancers';
require_once 'includes/header.php';

$categories = $conn->query("SELECT slug, name FROM categories ORDER BY id")->fetch_all(MYSQLI_ASSOC);

$people = $conn->query(
    "SELECT u.id, u.full_name, p.headline, p.bio, p.skills, p.rating, p.reviews_count, c.slug, c.icon
       FROM freelancer_profiles p
       JOIN users u      ON u.id = p.user_id
       JOIN categories c ON c.id = p.category_id
   ORDER BY p.rating DESC, p.reviews_count DESC"
)->fetch_all(MYSQLI_ASSOC);
?>
<section class="dark-section">
    <div class="container mt-5">
        <div class="filter-bar reveal">
            <input type="text" id="searchInput" class="form-control" placeholder="Search by name or skill...">
            <select id="categoryFilter" class="form-select">
                <option value="all">All Skills</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= e($c['slug']) ?>"><?= e($c['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="row g-4">
            <?php foreach ($people as $p): ?>
                <div class="col-lg-4 col-md-6 reveal filter-item" data-category="<?= e($p['slug']) ?>">
                    <div class="person-card">
                        <div class="avatar"><i class="bi <?= e($p['icon']) ?>"></i></div>
                        <h5><?= e($p['full_name']) ?></h5>
                        <p class="role"><?= e($p['headline']) ?></p>
                        <div class="rating"><?= stars((float)$p['rating']) ?>
                            <small><?= e($p['rating']) ?> (<?= (int)$p['reviews_count'] ?> reviews)</small></div>
                        <p><?= e($p['bio']) ?></p>
                        <div class="job-skills">
                            <?php foreach (skill_list($p['skills']) as $s): ?><span><?= e($s) ?></span><?php endforeach; ?>
                        </div>
                        <a href="contact.php?subject=<?= urlencode('Hire ' . $p['full_name']) ?>" class="btn btn-primary btn-sm px-4 mt-2">Hire Me</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <p class="no-results" <?= $people ? '' : 'style="display:block"' ?>><i class="bi bi-search"></i> No freelancers match your search.</p>
    </div>
</section>
<?php require 'includes/footer.php'; ?>
