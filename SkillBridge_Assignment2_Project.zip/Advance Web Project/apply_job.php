<?php
$pageTitle = 'Job Details';
$activeNav = 'jobs';
require_once 'includes/functions.php';

$jobId = (int)($_GET['id'] ?? $_POST['job_id'] ?? 0);

$stmt = $conn->prepare(
    "SELECT j.*, c.name AS category, c.icon, u.full_name AS client_name
       FROM jobs j JOIN categories c ON c.id = j.category_id JOIN users u ON u.id = j.client_id
      WHERE j.id = ?"
);
$stmt->bind_param('i', $jobId);
$stmt->execute();
$job = $stmt->get_result()->fetch_assoc();

if (!$job) {
    http_response_code(404);
    set_flash('danger', 'That job was not found.');
    redirect('find_job.php');
}

$errors = [];
$cover  = '';
$already = false;

if (has_role('freelancer')) {
    $chk = $conn->prepare("SELECT status FROM applications WHERE job_id = ? AND freelancer_id = ?");
    $chk->bind_param('ii', $jobId, $_SESSION['user_id']);
    $chk->execute();
    $already = $chk->get_result()->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_role('freelancer');                                   // only freelancers may apply
    $cover = trim($_POST['cover_letter'] ?? '');

    if (!csrf_valid())                    $errors[] = 'Invalid form token. Please refresh and try again.';
    if ($job['status'] !== 'open')        $errors[] = 'This job is closed.';
    if ($already)                         $errors[] = 'You have already applied for this job.';
    if (mb_strlen($cover) < 20 || mb_strlen($cover) > 2000) $errors[] = 'Cover letter must be 20 to 2000 characters.';

    if (!$errors) {
        $ins = $conn->prepare("INSERT INTO applications (job_id, freelancer_id, cover_letter) VALUES (?,?,?)");
        $ins->bind_param('iis', $jobId, $_SESSION['user_id'], $cover);
        $ins->execute();
        set_flash('success', 'Application submitted successfully!');
        redirect('apply_job.php?id=' . $jobId);
    }
}

require_once 'includes/header.php';
?>
<section class="dark-section">
    <div class="container mt-5">
        <a href="find_job.php" class="text-decoration-none"><i class="bi bi-arrow-left"></i> Back to jobs</a>
        <div class="row g-4 mt-1">
            <div class="col-lg-7">
                <div class="job-card">
                    <div class="job-top"><div class="job-icon"><i class="bi <?= e($job['icon']) ?>"></i></div>
                        <span class="badge text-bg-<?= $job['status'] === 'open' ? 'success' : 'secondary' ?> align-self-start"><?= e(ucfirst($job['status'])) ?></span></div>
                    <span class="job-category"><?= e($job['category']) ?></span>
                    <h4><?= e($job['title']) ?></h4>
                    <p class="text-muted small mb-3">Posted by <?= e($job['client_name']) ?> on <?= e(date('d M Y', strtotime($job['created_at']))) ?></p>
                    <p style="white-space:pre-line"><?= e($job['description']) ?></p>
                    <div class="job-skills"><?php foreach (skill_list($job['skills']) as $s): ?><span><?= e($s) ?></span><?php endforeach; ?></div>
                    <hr>
                    <small>Budget</small><h6>Rs. <?= number_format($job['budget']) ?></h6>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="form-card">
                    <h4 class="mb-3">Apply for this job</h4>
                    <?php if (!is_logged_in()): ?>
                        <p>Please log in as a freelancer to apply.</p>
                        <a class="btn btn-primary" href="login.php?next=<?= urlencode('apply_job.php?id=' . $jobId) ?>">Login to apply</a>
                    <?php elseif (!has_role('freelancer')): ?>
                        <div class="alert alert-info mb-0">Only freelancer accounts can apply for jobs.</div>
                    <?php elseif ($already): ?>
                        <div class="alert alert-success mb-0"><i class="bi bi-check-circle"></i> You applied for this job.
                            Status: <strong><?= e(ucfirst($already['status'])) ?></strong></div>
                    <?php elseif ($job['status'] !== 'open'): ?>
                        <div class="alert alert-secondary mb-0">This job is closed.</div>
                    <?php else: ?>
                        <?php foreach ($errors as $er): ?><div class="alert alert-danger"><?= e($er) ?></div><?php endforeach; ?>
                        <form method="post" action="apply_job.php?id=<?= $jobId ?>" novalidate>
                            <?= csrf_field() ?>
                            <input type="hidden" name="job_id" value="<?= $jobId ?>">
                            <label for="cover_letter">Cover letter</label>
                            <textarea id="cover_letter" name="cover_letter" rows="6" class="form-control mb-3" placeholder="Why are you a good fit?" required><?= e($cover) ?></textarea>
                            <button class="btn btn-primary w-100">Submit Application</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php require 'includes/footer.php'; ?>
