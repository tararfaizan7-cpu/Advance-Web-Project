<?php
$pageTitle = 'Login';
require_once 'includes/functions.php';

if (is_logged_in()) redirect(dashboard_url());

$error = '';
$email = '';
$next  = $_GET['next'] ?? $_POST['next'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    if (!csrf_valid()) {
        $error = 'Invalid form token. Please refresh and try again.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
        $error = 'Please enter your email and password.';
    } else {
        $stmt = $conn->prepare("SELECT id, full_name, email, password_hash, role FROM users WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if ($user && password_verify($password, $user['password_hash'])) {
            session_regenerate_id(true);                       // prevents session fixation
            $_SESSION['user_id']   = (int)$user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['email']     = $user['email'];
            $_SESSION['role']      = $user['role'];

            if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
                $newHash = password_hash($password, PASSWORD_DEFAULT);
                $u = $conn->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
                $u->bind_param('si', $newHash, $user['id']);
                $u->execute();
            }
            set_flash('success', 'Login successful! Welcome back, ' . $user['full_name'] . '.');
            redirect($user['role'] === 'admin' ? 'admin/index.php' : safe_next($next));
        }
        $error = 'Invalid email or password.';                 // same message for both cases
    }
}

require_once 'includes/header.php';
?>
<section class="auth-wrap">
    <div class="container">
        <div class="auth-card reveal">
            <div class="text-center mb-4">
                <div class="category-icon mx-auto"><i class="bi bi-box-arrow-in-right"></i></div>
                <h2>Welcome back</h2>
                <p>Log in to continue to SkillBridge.</p>
            </div>

            <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>

            <form method="post" action="login.php" novalidate>
                <?= csrf_field() ?>
                <input type="hidden" name="next" value="<?= e($next) ?>">
                <div class="mb-3">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="you@example.com" value="<?= e($email) ?>" required>
                </div>
                <div class="mb-3">
                    <label for="password">Password</label>
                    <div class="password-box">
                        <input type="password" id="password" name="password" class="form-control" placeholder="Enter password" required>
                        <button type="button" class="toggle-password"><i class="bi bi-eye"></i></button>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100 btn-lg mt-3">Login</button>
            </form>
            <p class="text-center mt-4 mb-0">New to SkillBridge? <a href="register.php">Create an account</a></p>
        </div>
    </div>
</section>
<?php require 'includes/footer.php'; ?>
