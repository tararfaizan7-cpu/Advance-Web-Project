<?php
$pageTitle = 'Join Now';
require_once 'includes/functions.php';

if (is_logged_in()) redirect(dashboard_url());

$errors = [];
$old = ['role' => 'freelancer', 'full_name' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old = [
        'role'      => $_POST['role'] ?? '',
        'full_name' => trim($_POST['full_name'] ?? ''),
        'email'     => strtolower(trim($_POST['email'] ?? '')),
    ];
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    /* ---- Server-side validation ---- */
    if (!csrf_valid()) $errors['form'] = 'Invalid form token. Please refresh and try again.';

    // Only these two roles can be self-registered. "admin" can never be chosen here.
    if (!in_array($old['role'], ['freelancer', 'client'], true)) $errors['role'] = 'Please choose Freelancer or Client.';

    if (!preg_match("/^[\p{L} .'-]{3,100}$/u", $old['full_name']))
        $errors['full_name'] = 'Name must be 3-100 characters (letters and spaces only).';

    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL) || strlen($old['email']) > 150)
        $errors['email'] = 'Please enter a valid email address.';

    if (strlen($password) < 8 || !preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password))
        $errors['password'] = 'Password must be at least 8 characters and contain a letter and a number.';

    if ($password !== $confirm) $errors['confirm_password'] = 'Passwords do not match.';

    if (empty($_POST['terms'])) $errors['terms'] = 'You must accept the Terms & Conditions.';

    // Email must be unique
    if (!isset($errors['email'])) {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param('s', $old['email']);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) $errors['email'] = 'This email is already registered.';
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);        // secure hashing
        $stmt = $conn->prepare("INSERT INTO users (full_name, email, password_hash, role) VALUES (?,?,?,?)");
        $stmt->bind_param('ssss', $old['full_name'], $old['email'], $hash, $old['role']);
        $stmt->execute();

        set_flash('success', 'Account created successfully! You can now log in.');
        redirect('login.php');
    }
}

require_once 'includes/header.php';
function err(array $errors, string $k): string
{
    return isset($errors[$k]) ? '<div class="invalid-feedback d-block">' . e($errors[$k]) . '</div>' : '';
}
function cls(array $errors, string $k): string { return isset($errors[$k]) ? ' is-invalid' : ''; }
?>
<section class="auth-wrap">
    <div class="container">
        <div class="auth-card reveal">
            <div class="text-center mb-4">
                <div class="category-icon mx-auto"><i class="bi bi-person-plus"></i></div>
                <h2>Create your account</h2>
                <p>Start your freelance journey today.</p>
            </div>

            <?php if (isset($errors['form'])): ?><div class="alert alert-danger"><?= e($errors['form']) ?></div><?php endif; ?>

            <form method="post" action="register.php" novalidate>
                <?= csrf_field() ?>
                <div class="role-switch">
                    <input type="radio" name="role" value="freelancer" id="roleFreelancer" <?= $old['role'] === 'freelancer' ? 'checked' : '' ?>>
                    <label for="roleFreelancer"><i class="bi bi-mortarboard"></i> Freelancer</label>
                    <input type="radio" name="role" value="client" id="roleClient" <?= $old['role'] === 'client' ? 'checked' : '' ?>>
                    <label for="roleClient"><i class="bi bi-briefcase"></i> Client</label>
                </div>
                <?= err($errors, 'role') ?>

                <div class="mb-3">
                    <label for="fullName">Full name</label>
                    <input type="text" id="fullName" name="full_name" class="form-control<?= cls($errors, 'full_name') ?>" value="<?= e($old['full_name']) ?>" required>
                    <?= err($errors, 'full_name') ?>
                </div>
                <div class="mb-3">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" class="form-control<?= cls($errors, 'email') ?>" placeholder="you@example.com" value="<?= e($old['email']) ?>" required>
                    <?= err($errors, 'email') ?>
                </div>
                <div class="mb-3">
                    <label for="password">Password</label>
                    <div class="password-box">
                        <input type="password" id="password" name="password" class="form-control<?= cls($errors, 'password') ?>" placeholder="At least 8 characters, letters + numbers" required>
                        <button type="button" class="toggle-password"><i class="bi bi-eye"></i></button>
                    </div>
                    <?= err($errors, 'password') ?>
                </div>
                <div class="mb-3">
                    <label for="confirmPassword">Confirm password</label>
                    <input type="password" id="confirmPassword" name="confirm_password" class="form-control<?= cls($errors, 'confirm_password') ?>" required>
                    <?= err($errors, 'confirm_password') ?>
                </div>
                <div class="form-check mb-4">
                    <input class="form-check-input<?= cls($errors, 'terms') ?>" type="checkbox" id="terms" name="terms" value="1" <?= !empty($_POST['terms']) ? 'checked' : '' ?>>
                    <label class="form-check-label fw-normal" for="terms">I agree to the <a href="#">Terms &amp; Conditions</a></label>
                    <?= err($errors, 'terms') ?>
                </div>
                <button type="submit" class="btn btn-primary w-100 btn-lg">Create Account</button>
            </form>
            <p class="text-center mt-4 mb-0">Already have an account? <a href="login.php">Login</a></p>
        </div>
    </div>
</section>
<?php require 'includes/footer.php'; ?>
