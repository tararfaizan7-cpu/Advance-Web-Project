<?php
$pageTitle = 'About';
$activeNav = 'about';
require_once 'includes/header.php';

$stats = [
    ['label' => 'Students',      'value' => $conn->query("SELECT COUNT(*) FROM users WHERE role='freelancer'")->fetch_row()[0]],
    ['label' => 'Jobs Posted',   'value' => $conn->query("SELECT COUNT(*) FROM jobs")->fetch_row()[0]],
    ['label' => 'Applications',  'value' => $conn->query("SELECT COUNT(*) FROM applications")->fetch_row()[0]],
    ['label' => 'Clients',       'value' => $conn->query("SELECT COUNT(*) FROM users WHERE role='client'")->fetch_row()[0]],
];

/* Team members (the project group) */
$team = [
    ['name' => 'Ayynoor Saeed',        'role' => 'Team Lead'],
    ['name' => 'Faizan Ahmad Tarar',   'role' => 'Group Member'],
    ['name' => 'Muhammad Abdullah',    'role' => 'Group Member'],
    ['name' => 'Azlan Amir',           'role' => 'Group Member'],
];
?>
<section class="dark-section">
    <div class="container">
        <div class="row align-items-center g-5 mt-5">
            <div class="col-lg-6 reveal-left">
                <h2 class="mb-3">Our Story</h2>
                <p class="lead-text">SkillBridge started with a simple problem: university students have great skills but few ways to prove them, while small businesses need affordable, fresh talent.</p>
                <p class="lead-text">We built a place where students can find paid projects, grow a portfolio and gain real experience before they graduate.</p>
            </div>
            <div class="col-lg-6 reveal-right">
                <div class="row g-3">
                    <?php foreach ($stats as $st): ?>
                        <div class="col-6"><div class="stat-box">
                            <h3><?= (int)$st['value'] ?></h3><p><?= e($st['label']) ?></p>
                        </div></div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="row g-4 mt-4">
            <div class="col-md-4 reveal"><div class="info-card">
                <div class="category-icon"><i class="bi bi-bullseye"></i></div>
                <h4>Our Mission</h4><p>Give every student a fair chance to earn from their skills.</p></div></div>
            <div class="col-md-4 reveal"><div class="info-card">
                <div class="category-icon"><i class="bi bi-eye"></i></div>
                <h4>Our Vision</h4><p>A community where learning and working happen side by side.</p></div></div>
            <div class="col-md-4 reveal"><div class="info-card">
                <div class="category-icon"><i class="bi bi-shield-check"></i></div>
                <h4>Our Values</h4><p>Trust, fair pay, clear communication and quality work.</p></div></div>
        </div>

        <div class="section-title reveal mt-5 pt-4">
            <h2 style="color:white">Meet the Team</h2>
            <p>The people building SkillBridge.</p>
        </div>
        <div class="row g-4">
            <?php foreach ($team as $m): ?>
                <div class="col-lg-3 col-md-6 reveal"><div class="person-card">
                    <div class="avatar"><i class="bi bi-person"></i></div>
                    <h5><?= e($m['name']) ?></h5><p class="role"><?= e($m['role']) ?></p>
                </div></div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="cta-section" style="background:white">
    <div class="container"><div class="cta-box reveal">
        <div><h2>Ready to turn your skills into opportunities?</h2><p>Join SkillBridge and start building your professional journey today.</p></div>
        <a href="register.php" class="btn btn-light btn-lg">Get Started <i class="bi bi-arrow-right"></i></a>
    </div></div>
</section>
<?php require 'includes/footer.php'; ?>
